<?php
/** اتصال جفتی: فقط محصولات موجود و فقط فیلدهای Stock. */
define( 'ABSPATH', __DIR__ . '/' );
if ( ! defined( 'ARRAY_A' ) ) { define( 'ARRAY_A', 'ARRAY_A' ); }
class WP_Error { private $code; private $message; public function __construct( $c = '', $m = '' ) { $this->code = $c; $this->message = $m; } public function get_error_code() { return $this->code; } public function get_error_message() { return $this->message; } }
function is_wp_error( $v ) { return $v instanceof WP_Error; }
function wp_parse_args( $a, $d ) { return array_merge( $d, (array) $a ); }
function sanitize_text_field( $v ) { return trim( (string) $v ); }
function sanitize_key( $v ) { return preg_replace( '/[^a-z0-9_\\-]/', '', strtolower( (string) $v ) ); }
function absint( $v ) { return abs( (int) $v ); }
function get_post_meta( $id, $key, $single = true ) { return isset( $GLOBALS['meta'][ $id ][ $key ] ) ? $GLOBALS['meta'][ $id ][ $key ] : ''; }
function update_post_meta( $id, $key, $value ) { $GLOBALS['meta'][ $id ][ $key ] = $value; return true; }
function delete_post_meta( $id, $key ) { unset( $GLOBALS['meta'][ $id ][ $key ] ); return true; }
function wc_get_product( $id ) { return isset( $GLOBALS['products'][ $id ] ) ? $GLOBALS['products'][ $id ] : null; }
function wc_delete_product_transients( $id ) {}
class TCAS_Test_WPDB {
	public $postmeta = 'wp_postmeta'; public $posts = 'wp_posts';
	public function prepare( $query, ...$args ) { foreach ( $args as $arg ) { $query = preg_replace( '/%s/', "'" . addslashes( (string) $arg ) . "'", $query, 1 ); $query = preg_replace( '/%d/', (string) (int) $arg, $query, 1 ); } return $query; }
	public function get_col( $query ) {
		preg_match( "/pm\.meta_key = '([^']+)'/", $query, $key ); preg_match( "/pm\.meta_value = '([^']*)'/", $query, $value ); $out = array();
		if ( isset( $value[1] ) ) {
			foreach ( $GLOBALS['meta'] as $id => $meta ) if ( isset( $key[1], $meta[ $key[1] ] ) && 0 === strcasecmp( (string) $meta[ $key[1] ], (string) $value[1] ) ) $out[] = $id;
		} elseif ( isset( $key[1] ) ) {
			// کوئری «مقدار خالی نیست» (پاک‌سازی مرجع‌های یتیم).
			foreach ( $GLOBALS['meta'] as $id => $meta ) if ( isset( $meta[ $key[1] ] ) && '' !== (string) $meta[ $key[1] ] ) $out[] = $id;
			if ( preg_match( "/code\.meta_key = '([^']+)'/", $query, $code_key ) ) {
				$out = array_values( array_filter( $out, function( $id ) use ( $code_key ) {
					return ! isset( $GLOBALS['meta'][ $id ][ $code_key[1] ] ) || '' === (string) $GLOBALS['meta'][ $id ][ $code_key[1] ];
				} ) );
			}
		}
		sort( $out ); return $out;
	}
	public function get_results( $query, $mode = null ) {
		preg_match( "/pm\.meta_key = '([^']+)'/", $query, $key );
		$rows = array();
		foreach ( $GLOBALS['meta'] as $id => $meta ) {
			if ( isset( $key[1], $meta[ $key[1] ] ) && '' !== (string) $meta[ $key[1] ] ) {
				$rows[] = array( 'id' => (string) $id, 'code' => (string) $meta[ $key[1] ] );
			}
		}
		return $rows;
	}
}
$GLOBALS['wpdb'] = new TCAS_Test_WPDB(); $GLOBALS['meta'] = array(); $GLOBALS['products'] = array();
class TCAS_Test_Product {
	private $id; private $type; private $parent; private $sku; private $name; private $price; private $status; private $description;
	private $manage = false; private $qty = null; private $stock_status = 'instock'; private $fail_save;
	private $attributes = array();
	public $saved = 0;
	public function __construct( $id, $sku, $type = 'simple', $parent = 0, $fail_save = false ) { $this->id = $id; $this->sku = $sku; $this->type = $type; $this->parent = $parent; $this->fail_save = $fail_save; $this->name = 'نام اصلی ' . $sku; $this->price = 9000.0; $this->status = 'publish'; $this->description = 'توضیح اصلی'; }
	public function get_id() { return $this->id; } public function get_parent_id() { return $this->parent; } public function get_type() { return $this->type; }
	public function is_type( $type ) { return $this->type === $type; } public function get_sku() { return $this->sku; } public function get_name() { return $this->name; } public function set_name( $n ) { $this->name = (string) $n; }
	public function get_regular_price() { return $this->price; } public function get_status() { return $this->status; } public function get_description() { return $this->description; }
	public function set_attributes( $attributes ) { $this->attributes = (array) $attributes; }
	public function get_attributes() { return $this->attributes; }
	public function get_manage_stock( $context = 'view' ) { return $this->manage; } public function get_stock_quantity( $context = 'view' ) { return $this->qty; } public function get_stock_status( $context = 'view' ) { return $this->stock_status; }
	public function set_manage_stock( $v ) { $this->manage = (bool) $v; } public function set_stock_quantity( $v ) { $this->qty = (float) $v; } public function set_stock_status( $v ) { $this->stock_status = $v; }
	public function save() { if ( $this->fail_save ) throw new Exception( 'save failed' ); $this->saved++; return $this->id; }
	public function __call( $method, $args ) { throw new Exception( 'Forbidden product field method: ' . $method ); }
}
class WC_Product_Variable { public static function sync_stock_status( $id, $save = true ) {} }
class TCAS_Api {
	public static $responses = array(); public static $calls = array();
	public static function fetch_product( $code ) { return self::fetch_reference( $code ); }
	public static function fetch_reference( $reference ) { self::$calls[] = $reference; return isset( self::$responses[ $reference ] ) ? self::$responses[ $reference ] : new WP_Error( 'not_found', 'محصول ArioCase پیدا نشد.' ); }
}
/** دوبل تنظیمات: این مجموعه رفتار نوشتن عددی را می‌سنجد. */
class TCAS_Core {
	public static $settings = array( 'stock_mode' => 'quantity' );
	public static function defaults() { return array( 'stock_mode' => 'quantity', 'fail_mode' => 'closed' ); }
	public static function settings() { return array_merge( self::defaults(), self::$settings ); }
}
require_once dirname( __DIR__ ) . '/includes/class-tcas-matcher.php';
require_once dirname( __DIR__ ) . '/includes/class-tcas-mapping.php';
require_once dirname( __DIR__ ) . '/includes/class-tcas-stock.php';
require_once dirname( __DIR__ ) . '/includes/class-tcas-pairing.php';
$pass = 0; $fail = 0;
function pair_test( $label, $condition, $detail = '' ) { global $pass, $fail; if ( $condition ) { $pass++; echo "OK   {$label}\n"; } else { $fail++; echo "FAIL {$label}" . ( $detail ? ' >> ' . $detail : '' ) . "\n"; } }
function local_product( $id, $sku, $type = 'simple', $parent = 0, $fail_save = false ) { $product = new TCAS_Test_Product( $id, $sku, $type, $parent, $fail_save ); $GLOBALS['products'][ $id ] = $product; $GLOBALS['meta'][ $id ]['_sku'] = $sku; return $product; }
function remote_product( $code, $over = array() ) { return array_merge( array( 'remote_id' => 100, 'parent_remote_id' => 0, 'code' => $code, 'name' => 'نام متفاوت ریموت', 'type' => 'simple', 'price' => 1.0, 'stock' => array( 'quantity' => 4.0, 'status' => 'instock' ), 'variations' => array() ), $over ); }
function pair_of( $local, $remote ) { return array( 'local_code' => $local, 'remote_code' => $remote, 'error' => '' ); }
function connect_pair( $local, $remote ) { $preview = TCAS_Pairing::preview( pair_of( $local, $remote ) ); return array( $preview, TCAS_Pairing::connect( $preview ) ); }

$product = local_product( 10, 'AR120' );
TCAS_Api::$responses['AR22'] = remote_product( 'AR22', array( 'remote_id' => 222 ) );
list( $preview, $result ) = connect_pair( 'AR120', 'AR22' );
pair_test( 'جفت دو کد متفاوت Preview و Connect می‌شود', 'connect' === $preview['row']['status'] && is_array( $result ) );
pair_test( 'هیچ محصولی ساخته یا حذف نمی‌شود', 1 === count( $GLOBALS['products'] ) && 10 === $result['product_id'] );
pair_test( 'نام، قیمت، SKU، توضیح و انتشار تغییر نمی‌کنند', 'نام اصلی AR120' === $product->get_name() && 9000.0 === $product->get_regular_price() && 'AR120' === $product->get_sku() && 'توضیح اصلی' === $product->get_description() && 'publish' === $product->get_status() );
pair_test( 'فقط Stock و نگاشت داخلی به‌روز می‌شوند', 4.0 === $product->get_stock_quantity() && $product->get_manage_stock() && 'AR22' === TCAS_Mapping::remote_code( 10 ) && 222 === TCAS_Mapping::remote_identifiers( 10 )['remote_id'] );
$again = TCAS_Pairing::preview( pair_of( 'AR120', 'AR22' ) );
pair_test( 'اجرای دوباره همان جفت را Connected نشان می‌دهد', 'connected' === $again['row']['status'] && ! $again['row']['selectable'] );

$before_calls = count( TCAS_Api::$calls ); $before_products = count( $GLOBALS['products'] );
$missing = TCAS_Pairing::preview( pair_of( 'NO-LOCAL', 'AR22' ) );
pair_test( 'محصول مفقود تیساکیس خطا است و API/ساخت محصول ندارد', 'error' === $missing['row']['status'] && $before_calls === count( TCAS_Api::$calls ) && $before_products === count( $GLOBALS['products'] ) );

local_product( 11, 'LOCAL-11' );
$missing_remote = connect_pair( 'LOCAL-11', 'NO-REMOTE' );
pair_test( 'محصول مفقود ArioCase هیچ نگاشتی نمی‌سازد', is_wp_error( $missing_remote[1] ) && '' === TCAS_Mapping::remote_code( 11 ) );

local_product( 12, 'LOCAL-12' ); local_product( 13, 'LOCAL-13' );
TCAS_Mapping::map( 12, 'OTHER-REMOTE', true );
$other = TCAS_Pairing::preview( pair_of( 'LOCAL-12', 'AR22' ) );
pair_test( 'کد دوم متفاوت با نگاشت قبلی رد می‌شود', 'error' === $other['row']['status'] && 'OTHER-REMOTE' === TCAS_Mapping::remote_code( 12 ) );
TCAS_Mapping::map( 13, 'USED-REMOTE', true ); local_product( 22, 'LOCAL-22' );
$used = TCAS_Pairing::preview( pair_of( 'LOCAL-22', 'USED-REMOTE' ) );
pair_test( 'کد ArioCase نمی‌تواند به دو SKU متصل شود', 'error' === $used['row']['status'] && '' === TCAS_Mapping::remote_code( 22 ) );

local_product( 14, 'lower-case' );
$case = TCAS_Pairing::preview( pair_of( 'LOWER-CASE', 'AR22' ) );
pair_test( 'Collation Case-insensitive باعث جفت اشتباه نمی‌شود', 'error' === $case['row']['status'] && '' === TCAS_Mapping::remote_code( 14 ) );

local_product( 15, 'LOCAL-15' ); TCAS_Api::$responses['REMOTE-VARIABLE'] = remote_product( 'REMOTE-VARIABLE', array( 'type' => 'variable' ) );
$mismatch = connect_pair( 'LOCAL-15', 'REMOTE-VARIABLE' );
pair_test( 'ساده با والد متغیر جفت نمی‌شود', is_wp_error( $mismatch[1] ) && '' === TCAS_Mapping::remote_code( 15 ) );
local_product( 16, 'PARENT-16', 'variable' ); $before_calls = count( TCAS_Api::$calls );
$parent = TCAS_Pairing::preview( pair_of( 'PARENT-16', 'REMOTE-VARIABLE' ) );
pair_test( 'والد متغیر بدون API رد می‌شود', 'error' === $parent['row']['status'] && $before_calls === count( TCAS_Api::$calls ) );

$variation = local_product( 17, 'LOCAL-VAR', 'variation', 100 );
TCAS_Api::$responses['REMOTE-VAR'] = remote_product( 'REMOTE-VAR', array( 'remote_id' => 601, 'parent_remote_id' => 600, 'type' => 'variation', 'stock' => array( 'quantity' => 7.0, 'status' => 'instock' ) ) );
list( $variation_preview, $variation_result ) = connect_pair( 'LOCAL-VAR', 'REMOTE-VAR' );
$variation_ids = TCAS_Mapping::remote_identifiers( 17 );
pair_test( 'Variation با Variation و با ID والد جفت می‌شود', is_array( $variation_result ) && 7.0 === $variation->get_stock_quantity() && 601 === $variation_ids['remote_id'] && 600 === $variation_ids['parent_remote_id'] );

local_product( 18, 'LOCAL-18' ); TCAS_Api::$responses['NO-STOCK'] = remote_product( 'NO-STOCK', array( 'stock' => array( 'quantity' => null, 'status' => null ) ) );
$no_stock = connect_pair( 'LOCAL-18', 'NO-STOCK' );
pair_test( 'نبود موجودی معتبر یعنی عدم اتصال', is_wp_error( $no_stock[1] ) && '' === TCAS_Mapping::remote_code( 18 ) );

local_product( 19, 'STALE-LOCAL' ); TCAS_Api::$responses['STALE-REMOTE'] = remote_product( 'STALE-REMOTE' );
$stale_preview = TCAS_Pairing::preview( pair_of( 'STALE-LOCAL', 'STALE-REMOTE' ) );
unset( $GLOBALS['products'][19], $GLOBALS['meta'][19] ); local_product( 20, 'STALE-LOCAL' );
$stale_result = TCAS_Pairing::connect( $stale_preview );
pair_test( 'Preview کهنه به محصول جایگزین وصل نمی‌شود', is_wp_error( $stale_result ) && '' === TCAS_Mapping::remote_code( 20 ) );

local_product( 21, 'FAIL-SAVE', 'simple', 0, true ); TCAS_Api::$responses['FAIL-REMOTE'] = remote_product( 'FAIL-REMOTE' );
$failed = connect_pair( 'FAIL-SAVE', 'FAIL-REMOTE' );
pair_test( 'خطای ذخیرهٔ Stock نگاشت تازه را Rollback می‌کند', is_wp_error( $failed[1] ) && '' === TCAS_Mapping::remote_code( 21 ) );

local_product( 23, 'LINK-LOCAL' );
$link = 'https://ariocase.com/product/resolved-case/';
TCAS_Api::$responses[ $link ] = remote_product( 'LINK-RESOLVED', array( 'remote_id' => 777 ) );
list( $link_preview, $link_result ) = connect_pair( 'LINK-LOCAL', $link );
pair_test( 'لینک به SKU واقعی تبدیل و فقط همان SKU نگاشت می‌شود', is_array( $link_result ) && 'LINK-RESOLVED' === $link_preview['row']['remote_code'] && 'LINK-RESOLVED' === TCAS_Mapping::remote_code( 23 ) && 777 === TCAS_Mapping::remote_identifiers( 23 )['remote_id'] );
$link_again = TCAS_Pairing::preview( pair_of( 'LINK-LOCAL', $link ) );
pair_test( 'پیش‌نمایش دوباره با همان لینک، اتصال موجود را تشخیص می‌دهد', 'connected' === $link_again['row']['status'] && 'LINK-RESOLVED' === $link_again['row']['remote_code'] );

local_product( 24, 'ID-LINK-LOCAL' );
$id_link = 'https://ariocase.com/product/id-only-case/';
TCAS_Api::$responses[ $id_link ] = remote_product( '', array( 'remote_id' => 658 ) );
list( $id_link_preview, $id_link_result ) = connect_pair( 'ID-LINK-LOCAL', $id_link );
pair_test( 'لینک بدون SKU به ID canonical نگاشت و فقط Stock اعمال می‌شود', is_array( $id_link_result ) && 'ID:658' === $id_link_preview['row']['remote_code'] && 'ID:658' === TCAS_Mapping::remote_code( 24 ) && 658 === TCAS_Mapping::remote_identifiers( 24 )['remote_id'] && 4.0 === $GLOBALS['products'][24]->get_stock_quantity() );
$id_link_again = TCAS_Pairing::preview( pair_of( 'ID-LINK-LOCAL', $id_link ) );
pair_test( 'لینک ID-only در Preview دوباره Connected تشخیص داده می‌شود', 'connected' === $id_link_again['row']['status'] && 'ID:658' === $id_link_again['row']['remote_code'] );

local_product( 25, 'ID-DIRECT-LOCAL' );
TCAS_Api::$responses['ID:659'] = remote_product( '', array( 'remote_id' => 659 ) );
list( $id_direct_preview, $id_direct_result ) = connect_pair( 'ID-DIRECT-LOCAL', 'ID:659' );
pair_test( 'مرجع مستقیم ID در Preview و Connect حفظ می‌شود', is_array( $id_direct_result ) && 'ID:659' === $id_direct_preview['row']['remote_code'] && 'ID:659' === TCAS_Mapping::remote_code( 25 ) && 659 === TCAS_Mapping::remote_identifiers( 25 )['remote_id'] );
local_product( 26, 'NO-IDENTITY-LOCAL' );
TCAS_Api::$responses['NO-IDENTITY'] = remote_product( '', array( 'remote_id' => 0 ) );
$no_identity = TCAS_Pairing::preview( pair_of( 'NO-IDENTITY-LOCAL', 'NO-IDENTITY' ) );
pair_test( 'محصول بدون SKU و ID نگاشت جعلی نمی‌سازد', 'error' === $no_identity['row']['status'] && '' === TCAS_Mapping::remote_code( 26 ) );

local_product( 27, 'LOCAL-ID-VAR', 'variation', 100 );
TCAS_Api::$responses['ID:700/701'] = remote_product( '', array( 'remote_id' => 701, 'parent_remote_id' => 700, 'type' => 'variation', 'stock' => array( 'quantity' => 8.0, 'status' => 'instock' ) ) );
list( $id_variation_preview, $id_variation_result ) = connect_pair( 'LOCAL-ID-VAR', 'ID:700/701' );
$id_variation_ids = TCAS_Mapping::remote_identifiers( 27 );
pair_test( 'Variation بدون SKU با مرجع والد/تنوع جفت و نگاشت می‌شود', is_array( $id_variation_result ) && 'ID:700/701' === $id_variation_preview['row']['remote_code'] && 'ID:700/701' === TCAS_Mapping::remote_code( 27 ) && 701 === $id_variation_ids['remote_id'] && 700 === $id_variation_ids['parent_remote_id'] && 8.0 === $GLOBALS['products'][27]->get_stock_quantity() );
$id_variation_again = TCAS_Pairing::preview( pair_of( 'LOCAL-ID-VAR', 'ID:700/701' ) );
pair_test( 'مرجع Variation در Preview دوباره Connected می‌شود', 'connected' === $id_variation_again['row']['status'] && 'ID:700/701' === $id_variation_again['row']['remote_code'] );

local_product( 200, 'SB193', 'variable' );
local_product( 201, 'SB193', 'variation', 200 );
local_product( 202, 'SB193', 'variation', 200 );
TCAS_Api::$responses['ID:700/702'] = remote_product( '', array( 'remote_id' => 702, 'parent_remote_id' => 700, 'type' => 'variation', 'stock' => array( 'quantity' => 6.0, 'status' => 'instock' ) ) );
list( $shared_id_preview, $shared_id_result ) = connect_pair( 'ID:201', 'ID:700/702' );
pair_test( 'با SKU مشترک، ID تیساکیس فقط همان Variation را جفت می‌کند', is_array( $shared_id_result ) && 201 === $shared_id_result['product_id'] && 'ID:201' === $shared_id_preview['row']['local_code'] && 'ID:700/702' === TCAS_Mapping::remote_code( 201 ) && 6.0 === $GLOBALS['products'][201]->get_stock_quantity() && '' === TCAS_Mapping::remote_code( 202 ) );
$shared_id_again = TCAS_Pairing::preview( pair_of( 'ID:201', 'ID:700/702' ) );
pair_test( 'اتصال Variation با ID در Preview دوباره Connected می‌شود', 'connected' === $shared_id_again['row']['status'] && 201 === $shared_id_again['local_id'] );
$before_shared_sku_calls = count( TCAS_Api::$calls );
$shared_sku = TCAS_Pairing::preview( pair_of( 'SB193', 'ID:700/703' ) );
pair_test( 'ورود دستی SKU مشترک بدون API و با راهنمای ID رد می‌شود', 'error' === $shared_sku['row']['status'] && false !== strpos( $shared_sku['row']['message'], 'ID' ) && $before_shared_sku_calls === count( TCAS_Api::$calls ) );
$missing_local_id = TCAS_Pairing::preview( pair_of( 'ID:999', 'ID:700/704' ) );
pair_test( 'ID ناموجود تیساکیس محصول جعلی نمی‌سازد', 'error' === $missing_local_id['row']['status'] && 0 === $missing_local_id['local_id'] && ! isset( $GLOBALS['products'][999] ) );

local_product( 301, 'LOCAL-PARTNER-A' ); local_product( 302, 'LOCAL-PARTNER-B' );
$map_a = TCAS_Mapping::map( 301, 'SAME-REMOTE-REF', true, 'vendor_a' );
$map_b = TCAS_Mapping::map( 302, 'SAME-REMOTE-REF', true, 'ariocase' );
pair_test( 'همان مرجع ریموت می‌تواند در providerهای جدا به محصولات متفاوت متصل شود', true === $map_a && true === $map_b && array( 301 ) === TCAS_Mapping::ids_by_remote_code( 'SAME-REMOTE-REF', 'vendor_a' ) && array( 302 ) === TCAS_Mapping::ids_by_remote_code( 'SAME-REMOTE-REF', 'ariocase' ) );
$cross_provider_remap = TCAS_Mapping::map( 301, 'OTHER-REF', true, 'vendor_b' );
pair_test( 'یک محصول برای جلوگیری از تداخل موجودی هم‌زمان به provider دوم منتقل نمی‌شود', is_wp_error( $cross_provider_remap ) && 'vendor_a' === TCAS_Mapping::partner_id( 301 ) );

// --- فهرست مدل: یک مرجع همکار روی چند Variation تیساکیس ---
TCAS_Core::$settings = array( 'stock_mode' => 'quantity' );
$a52  = local_product( 70, 'A52' );
$a52s = local_product( 71, 'A52s' );
TCAS_Api::$responses['A52-MERGED'] = remote_product( 'A52-MERGED', array( 'stock' => array( 'quantity' => 3.0, 'status' => 'instock' ) ) );
list( $first_preview, $first_result ) = connect_pair( 'A52', 'A52-MERGED' );
pair_test( 'اولین Variation فهرست مدل عادی وصل می‌شود', ! is_wp_error( $first_result ) && 'A52-MERGED' === TCAS_Mapping::remote_code( 70 ) );
list( $duplicate_preview, $duplicate_result ) = connect_pair( 'A52s', 'A52-MERGED' );
pair_test( 'بدون پرچم فهرست مدل، مرجع تکراری همچنان رد می‌شود', is_wp_error( $duplicate_result ) && '' === TCAS_Mapping::remote_code( 71 ) );

$shared_preview = TCAS_Pairing::preview( array( 'local_code' => 'A52s', 'remote_code' => 'A52-MERGED', 'error' => '', 'shared_remote' => true ) );
pair_test( 'پیش‌نمایش با پرچم اشتراک، کارت را قابل اتصال و با پیام مشترک می‌سازد', 'connect' === $shared_preview['row']['status'] && ! empty( $shared_preview['row']['shared_remote'] ) && false !== strpos( $shared_preview['row']['message'], 'همین موجودی' ) );
$shared_result = TCAS_Pairing::connect( $shared_preview );
pair_test( 'دومین Variation تیساکیس هم به همان Variation همکار وصل می‌شود', ! is_wp_error( $shared_result ) && 'A52-MERGED' === TCAS_Mapping::remote_code( 71 ) && 'A52-MERGED' === TCAS_Mapping::remote_code( 70 ) );
pair_test( 'هر دو Variation موجودی همان مرجع را می‌گیرند', 3.0 === (float) $a52->get_stock_quantity() && 3.0 === (float) $a52s->get_stock_quantity() );

// --- مرجع مشترک خودکار: برچسب خود Variation همکار چند مدل دارد («Samsung A52 / A52s») ---
TCAS_Core::$settings = array( 'stock_mode' => 'quantity' );
local_product( 72, 'SKU-72' );
local_product( 73, 'SKU-73' );
local_product( 74, 'SKU-74' );
$GLOBALS['products'][72]->set_name( 'قاب چرم A52 ـ روشن' );
$GLOBALS['products'][73]->set_name( 'قاب چرم A52s ـ روشن' );
$GLOBALS['products'][74]->set_name( 'قاب چرم A54 ـ روشن' );
TCAS_Api::$responses['MERGED-LABEL'] = remote_product( 'MERGED-LABEL', array( 'name' => 'Samsung A52 / A52s', 'remote_id' => 47978, 'stock' => array( 'quantity' => 5.0, 'status' => 'instock' ) ) );
list( $auto_first, $auto_first_result ) = connect_pair( 'ID:72', 'MERGED-LABEL' );
pair_test( 'کارت اول برچسب چندمدلی بدون پرچم کلاینت وصل می‌شود', ! is_wp_error( $auto_first_result ) && 'MERGED-LABEL' === TCAS_Mapping::remote_code( 72 ) );
$auto_second = TCAS_Pairing::preview( pair_of( 'ID:73', 'MERGED-LABEL' ) );
pair_test( 'بدون پرچم کلاینت، برچسب چندمدلی همکار خودکار مشترک شناخته می‌شود', 'connect' === $auto_second['row']['status'] && ! empty( $auto_second['row']['shared_remote'] ) );
$auto_second_result = TCAS_Pairing::connect( $auto_second );
pair_test( 'کارت دوم همان مرجع مشترک را می‌گیرد و موجودی یکی است', ! is_wp_error( $auto_second_result ) && 'MERGED-LABEL' === TCAS_Mapping::remote_code( 73 ) && 5.0 === (float) $GLOBALS['products'][73]->get_stock_quantity() );

$not_in_list = TCAS_Pairing::preview( pair_of( 'ID:74', 'MERGED-LABEL' ) );
pair_test( 'مدلی که در فهرست برچسب همکار نیست همچنان مرجع تکراری می‌گیرد', 'error' === $not_in_list['row']['status'] && false !== strpos( $not_in_list['row']['message'], '#72' ) && '' === TCAS_Mapping::remote_code( 74 ) );

// --- کارت‌های از قبل متصل: بدون درخواست تازه ---
$before_recheck = count( TCAS_Api::$calls );
$recheck = TCAS_Pairing::preview( pair_of( 'ID:72', 'MERGED-LABEL' ) );
pair_test( 'جفت از قبل متصل بدون هیچ درخواستی به همکار Connected برمی‌گردد', 'connected' === $recheck['row']['status'] && ! $recheck['row']['selectable'] && $before_recheck === count( TCAS_Api::$calls ) && false !== strpos( $recheck['row']['message'], 'تکراری' ) );

$marked = TCAS_Pairing::annotate( array(
	array( 'local_code' => 'ID:72', 'remote_code' => 'MERGED-LABEL' ),
	array( 'local_code' => 'ID:74', 'remote_code' => 'MERGED-LABEL' ),
	array( 'local_code' => 'ID:73', 'remote_code' => 'MERGED-LABEL' ),
	array( 'local_code' => 'ID:900', 'remote_code' => 'MERGED-LABEL' ),
), 'ariocase' );
$marked_by_code = array();
foreach ( $marked['matches'] as $marked_match ) {
	$marked_by_code[ $marked_match['local_code'] ] = $marked_match;
}
pair_test( 'فقط Variationهایی که با همین مرجع وصل‌اند «از قبل متصل» علامت می‌خورند', 2 === $marked['connected'] && ! empty( $marked_by_code['ID:72']['connected'] ) && ! empty( $marked_by_code['ID:73']['connected'] ) && empty( $marked_by_code['ID:74']['connected'] ) && empty( $marked_by_code['ID:900']['connected'] ) );
pair_test( 'مرجع اشغال‌شده کارت می‌گیرد، ولی با پرچم انتقال تا از چشم نیفتد', 2 === $marked['skipped'] && 2 === count( $marked['taken'] ) && 'ID:74' === $marked['taken'][0]['local_code'] && 72 === $marked['taken'][0]['taken_by'] && ! empty( $marked_by_code['ID:74']['reclaim'] ) && ! empty( $marked_by_code['ID:900']['reclaim'] ) && 4 === count( $marked['matches'] ) );
$bundled_marked = TCAS_Pairing::annotate( array(
	array( 'local_code' => 'ID:74', 'remote_code' => 'MERGED-LABEL', 'remote_label' => 'A52 / A52s' ),
), 'ariocase' );
pair_test( 'اگر برچسب همکار چندمدلی باشد، همان مرجع برای Variation دوم آزاد می‌ماند', 0 === $bundled_marked['skipped'] && ! empty( $bundled_marked['matches'][0]['shared_remote'] ) );

TCAS_Mapping::map( 73, 'MERGED-LABEL', false, 'ariocase', true );
$disabled_marked = TCAS_Pairing::mark_connected( array( array( 'local_code' => 'ID:73', 'remote_code' => 'MERGED-LABEL' ) ), 'ariocase' );
pair_test( 'نگاشت غیرفعال دوباره ارسال می‌شود (از قبل متصل حساب نمی‌شود)', 0 === $disabled_marked['connected'] );

$other_code = TCAS_Pairing::mark_connected( array( array( 'local_code' => 'ID:70', 'remote_code' => 'SOMETHING-ELSE' ) ), 'ariocase' );
pair_test( 'اگر مرجع تازه با مرجع ذخیره‌شده یکی نباشد، کارت دوباره بررسی می‌شود', 0 === $other_code['connected'] );

// --- انتقال مرجع با تأیید: از Variation قبلی برداشته و به Variation جدید داده می‌شود ---
local_product( 80, 'SKU-80' );
local_product( 81, 'SKU-81' );
TCAS_Api::$responses['MOVE-1'] = remote_product( 'MOVE-1', array( 'name' => 'Case MOVE', 'remote_id' => 55123, 'stock' => array( 'quantity' => 7.0, 'status' => 'instock' ) ) );
list( $move_a, $move_a_result ) = connect_pair( 'ID:80', 'MOVE-1' );
pair_test( 'Variation اول به مرجع انتقال وصل می‌شود', ! is_wp_error( $move_a_result ) && 'MOVE-1' === TCAS_Mapping::remote_code( 80 ) );
$move_blocked = TCAS_Pairing::preview( pair_of( 'ID:81', 'MOVE-1' ) );
pair_test( 'بدون تأیید کاربر هیچ انتقالی انجام نمی‌شود', 'error' === $move_blocked['row']['status'] && false !== strpos( $move_blocked['row']['message'], '#80' ) && '' === TCAS_Mapping::remote_code( 81 ) );
$move_preview = TCAS_Pairing::preview( array_merge( pair_of( 'ID:81', 'MOVE-1' ), array( 'reclaim' => true ) ) );
pair_test( 'با تأیید، کارت قابل انتقال می‌شود و محصول قبلی را نام می‌برد', 'connect' === $move_preview['row']['status'] && $move_preview['row']['selectable'] && 80 === (int) $move_preview['row']['reclaim'] && false !== strpos( $move_preview['row']['message'], '#80' ) );
$move_result = TCAS_Pairing::connect( $move_preview );
pair_test( 'انتقال انجام شد: نگاشت قبلی حذف و مرجع روی Variation جدید ثبت شد', ! is_wp_error( $move_result ) && 'MOVE-1' === TCAS_Mapping::remote_code( 81 ) && '' === TCAS_Mapping::remote_code( 80 ) && false !== strpos( $move_result['message'], '#80' ) );

// --- مرجع یتیم: اتصال حذف شده ولی شناسهٔ قدیمی همکار روی محصول مانده ---
local_product( 85, 'SKU-85' );
local_product( 86, 'SKU-86' );
TCAS_Api::$responses['STALE-1'] = remote_product( 'STALE-1', array( 'name' => 'Case STALE', 'remote_id' => 66001, 'stock' => array( 'quantity' => 2.0, 'status' => 'instock' ) ) );
list( $stale_a, $stale_a_result ) = connect_pair( 'ID:85', 'STALE-1' );
pair_test( 'Variation اول به مرجع یتیم‌شده وصل می‌شود', ! is_wp_error( $stale_a_result ) && 'STALE-1' === TCAS_Mapping::remote_code( 85 ) );
TCAS_Mapping::forget( 85 );
update_post_meta( 85, TCAS_Mapping::META_REMOTE_ID, 66001 );
pair_test( 'قطع اتصال، مرجع را از فهرست صاحبان زنده حذف می‌کند', ! in_array( 85, TCAS_Mapping::holders_of( 'ID:66001' ), true ) && in_array( 85, TCAS_Mapping::holders_of( 'ID:66001', 'ariocase', false ), true ) );
$stale_preview = TCAS_Pairing::preview( pair_of( 'ID:86', 'STALE-1' ) );
pair_test( 'مرجع یتیم مانع اتصال Variation تازه نمی‌شود', 'connect' === $stale_preview['row']['status'] && $stale_preview['row']['selectable'] );
pair_test( 'پاک‌سازی مرجع‌های یتیم، متای قدیمی را حذف می‌کند', TCAS_Mapping::prune_stale() >= 1 && '' === (string) get_post_meta( 85, TCAS_Mapping::META_REMOTE_ID, true ) );

// --- نگاشت خراب: محصول حذف شده ولی مرجعش روی متا مانده ---
local_product( 88, 'SKU-88' );
local_product( 89, 'SKU-89' );
TCAS_Api::$responses['BROKEN-1'] = remote_product( 'BROKEN-1', array( 'name' => 'Case BROKEN', 'remote_id' => 77001, 'stock' => array( 'quantity' => 3.0, 'status' => 'instock' ) ) );
list( $broken_a, $broken_a_result ) = connect_pair( 'ID:88', 'BROKEN-1' );
pair_test( 'Variation اول به مرجع وصل می‌شود', ! is_wp_error( $broken_a_result ) && 'BROKEN-1' === TCAS_Mapping::remote_code( 88 ) );
unset( $GLOBALS['products'][88] ); // محصول دیگر بارگذاری نمی‌شود (حذف‌شده/خراب)
pair_test( 'نگاشت خراب صاحب مرجع حساب نمی‌شود', ! in_array( 88, TCAS_Mapping::holders_of( 'ID:77001' ), true ) );
$broken_preview = TCAS_Pairing::preview( pair_of( 'ID:89', 'BROKEN-1' ) );
pair_test( 'نگاشت خراب مانع اتصال Variation تازه نمی‌شود', 'connect' === $broken_preview['row']['status'] );
$broken_rows = TCAS_Mapping::orphans();
pair_test( 'نگاشت خراب در فهرست تشخیصی دیده می‌شود', 1 === count( $broken_rows ) && 88 === (int) $broken_rows[0]['id'] && 'BROKEN-1' === $broken_rows[0]['code'] );
pair_test( 'پاک‌سازی نگاشت خراب، متایش را حذف می‌کند', 1 === TCAS_Mapping::clear_broken() && '' === (string) TCAS_Mapping::remote_code( 88 ) );

// --- حالت flag: فقط موجود/ناموجود ---
TCAS_Core::$settings = array( 'stock_mode' => 'flag' );
$flag_product = local_product( 60, 'FLAG-1' );
TCAS_Api::$responses['FLAG-R'] = remote_product( 'FLAG-R', array( 'stock' => array( 'quantity' => 0.0, 'status' => 'instock' ) ) );
connect_pair( 'FLAG-1', 'FLAG-R' );
pair_test( 'حالت flag فقط وضعیت را می‌نویسد و انبار عددی محلی را دست نمی‌زند', 'outofstock' === $flag_product->get_stock_status() && null === $flag_product->get_stock_quantity() && false === $flag_product->get_manage_stock() );


// --- 1.29.0: تشخیص مرجع مشترک از Attributeها، محافظ پرچم و مدل خارج از فهرست ---
TCAS_Core::$settings = array( 'stock_mode' => 'quantity' );
local_product( 501, 'SKU-501' );
local_product( 502, 'SKU-502' );
local_product( 503, 'SKU-503' );
$GLOBALS['products'][501]->set_attributes( array( 'pa_model' => 'A52' ) );
$GLOBALS['products'][502]->set_attributes( array( 'pa_model' => 'A52s' ) );
$GLOBALS['products'][503]->set_name( 'قاب چرم A54' );
TCAS_Api::$responses['ATTR-BUNDLE'] = remote_product( 'ATTR-BUNDLE', array(
	'name'                 => 'قاب سامسونگ',
	'variation_attributes' => array( 'مدل' => 'Samsung A52 / A52s' ),
	'stock'                => array( 'quantity' => 8.0, 'status' => 'instock' ),
) );
list( $attr_first, $attr_first_result ) = connect_pair( 'ID:501', 'ATTR-BUNDLE' );
pair_test( 'کارت اول یک فهرست مدل موجود در Attribute همکار وصل میشود', ! is_wp_error( $attr_first_result ) && 'ATTR-BUNDLE' === TCAS_Mapping::remote_code( 501 ) );
$attr_second = TCAS_Pairing::preview( pair_of( 'ID:502', 'ATTR-BUNDLE' ) );
pair_test( 'بدون پرچم کلاینت، فهرست مدل از Attribute همکار شناسایی میشود', 'connect' === $attr_second['row']['status'] && ! empty( $attr_second['row']['shared_remote'] ) );
$attr_second_result = TCAS_Pairing::connect( $attr_second );
pair_test( 'کارت دوم همان مرجع را میگیرد و موجودی یکی مینشیند', ! is_wp_error( $attr_second_result ) && 'ATTR-BUNDLE' === TCAS_Mapping::remote_code( 502 ) && 8.0 === (float) $GLOBALS['products'][502]->get_stock_quantity() );

$outside = TCAS_Pairing::preview( array_merge( pair_of( 'ID:503', 'ATTR-BUNDLE' ), array( 'shared_remote' => true ) ) );
pair_test( 'پرچم جعلی برای مدل بیرون از فهرست، محافظ یکتایی را دور نمیزند', 'error' === $outside['row']['status'] && empty( $outside['row']['shared_remote'] ) && ! empty( $outside['row']['shared_rejected'] ) && false !== strpos( $outside['row']['message'], 'تأیید نشد' ) && '' === TCAS_Mapping::remote_code( 503 ) );
$outside_connect = TCAS_Pairing::connect( $outside );
pair_test( 'کارت ردشده هنگام اتصال هم نگاشتی نمیسازد', is_wp_error( $outside_connect ) && '' === TCAS_Mapping::remote_code( 503 ) );

local_product( 504, 'SKU-504' );
$GLOBALS['products'][504]->set_name( 'قاب A52s' );
$annotated = TCAS_Pairing::annotate( array(
	array( 'local_code' => 'ID:504', 'remote_code' => 'ATTR-BUNDLE', 'remote_label' => 'Samsung A52 / A52s', 'local_label' => 'A52s' ),
	array( 'local_code' => 'ID:503', 'remote_code' => 'ATTR-BUNDLE', 'remote_label' => 'Samsung A52 / A52s', 'local_label' => 'قاب A54' ),
), 'ariocase' );
pair_test( 'تشخیص کارت فقط برای مدل داخل فهرست آزاد میماند، مدل بیرونی «اشغالشده» است', 1 === $annotated['skipped'] && ! empty( $annotated['matches'][0]['shared_remote'] ) && ! empty( $annotated['matches'][1]['reclaim'] ), json_encode( $annotated['matches'], JSON_UNESCAPED_UNICODE ) );

// پرچم کلاینت بدون مدرک و بدون نگاشت همخانواده پذیرفته نمیشود.
local_product( 510, 'SKU-510' );
local_product( 511, 'SKU-511' );
$GLOBALS['products'][510]->set_name( 'قاب A52' );
$GLOBALS['products'][511]->set_name( 'قاب B99' );
TCAS_Api::$responses['PLAIN-BUNDLE'] = remote_product( 'PLAIN-BUNDLE', array( 'name' => 'قاب ساده', 'stock' => array( 'quantity' => 2.0, 'status' => 'instock' ) ) );
connect_pair( 'ID:510', 'PLAIN-BUNDLE' );
$stale_flag = TCAS_Pairing::preview( array_merge( pair_of( 'ID:511', 'PLAIN-BUNDLE' ), array( 'shared_remote' => true ) ) );
pair_test( 'پرچم کهنه با مدل ناخویشاوند و برچسب تکمدلی رد میشود', 'error' === $stale_flag['row']['status'] && empty( $stale_flag['row']['shared_remote'] ) && '' === TCAS_Mapping::remote_code( 511 ) );

// فهرست کاماجدای همکار: تشخیص سروری بدون پرچم.
local_product( 520, 'SKU-520' );
local_product( 521, 'SKU-521' );
$GLOBALS['products'][520]->set_name( 'قاب A30s' );
$GLOBALS['products'][521]->set_name( 'قاب A50s' );
TCAS_Api::$responses['COMMA-BUNDLE'] = remote_product( 'COMMA-BUNDLE', array( 'name' => 'A30s,A50,A50s', 'stock' => array( 'quantity' => 6.0, 'status' => 'instock' ) ) );
connect_pair( 'ID:520', 'COMMA-BUNDLE' );
$comma_second = TCAS_Pairing::preview( pair_of( 'ID:521', 'COMMA-BUNDLE' ) );
pair_test( 'فهرست کاماجدای همکار، کارت دوم را بدون پرچم مشترک میکند', 'connect' === $comma_second['row']['status'] && ! empty( $comma_second['row']['shared_remote'] ) );

// قالب «attributes» نرمالساز (name + options) هم منبع مدرک است.
local_product( 530, 'SKU-530' );
local_product( 531, 'SKU-531' );
$GLOBALS['products'][530]->set_name( 'قاب A52' );
$GLOBALS['products'][531]->set_name( 'قاب A52s' );
TCAS_Api::$responses['OPTIONS-BUNDLE'] = remote_product( 'OPTIONS-BUNDLE', array(
	'name'       => 'قاب ساده',
	'attributes' => array( array( 'name' => 'مدل', 'options' => array( 'Samsung A52 / A52s' ) ) ),
	'stock'      => array( 'quantity' => 4.0, 'status' => 'instock' ),
) );
connect_pair( 'ID:530', 'OPTIONS-BUNDLE' );
$options_second = TCAS_Pairing::preview( pair_of( 'ID:531', 'OPTIONS-BUNDLE' ) );
pair_test( 'فهرست مدل داخل optionsـِ Attribute همکار هم تشخیص داده میشود', 'connect' === $options_second['row']['status'] && ! empty( $options_second['row']['shared_remote'] ) );


// --- 1.30.0: هویت مرجع «ID:والد/Variation» بدون خطای PCRE ---
$case_identity = TCAS_Mapping::identity_from_reference( 'ID:44616/44665' );
$plain_identity = TCAS_Mapping::identity_from_reference( 'ID:44616' );
pair_test( 'هویت مرجع ID:والد/Variation درست خوانده میشود (بدون اخطار PCRE)', 44616 === $case_identity['parent_id'] && 44665 === $case_identity['remote_id'], json_encode( $case_identity ) );
pair_test( 'هویت مرجع ID تکی همچنان درست است', 0 === $plain_identity['parent_id'] && 44616 === $plain_identity['remote_id'] );


// --- 1.31.0: منبع حقیقت «متصل بودن» فقط نگاشت زندهٔ همین سایت ---
local_product( 600, 'SKU-600' );
$verify_pair = array( 'local_code' => 'ID:600', 'remote_code' => 'VERIFY-1' );
pair_test( 'بدون نگاشت، connected_state ادعای اتصال نمیکند', ! TCAS_Pairing::connected_state( $verify_pair ) );
TCAS_Mapping::map( 600, 'VERIFY-1', true, 'ariocase', false );
pair_test( 'نگاشت زنده و فعال، متصل است', TCAS_Pairing::connected_state( $verify_pair ) );
pair_test( 'مرجع متفاوت، متصل حساب نمیشود', ! TCAS_Pairing::connected_state( array( 'local_code' => 'ID:600', 'remote_code' => 'VERIFY-2' ) ) );
TCAS_Mapping::map( 600, 'VERIFY-1', false, 'ariocase', false );
pair_test( 'نگاشت غیرفعال، متصل حساب نمیشود', ! TCAS_Pairing::connected_state( $verify_pair ) );
TCAS_Mapping::forget( 600 );
pair_test( 'بعد از قطع اتصال، متصل حساب نمیشود', ! TCAS_Pairing::connected_state( $verify_pair ) );
TCAS_Mapping::map( 600, 'VERIFY-1', true, 'ariocase', false );
$connected_preview = TCAS_Pairing::preview( pair_of( 'ID:600', 'VERIFY-1' ) );
pair_test( 'Preview جفت متصل، وضعیت connected برمیگرداند', 'connected' === $connected_preview['row']['status'] && false === $connected_preview['row']['selectable'] );
$connect_again = TCAS_Pairing::connect( $connected_preview );
pair_test( 'اتصال دوبارهٔ جفت متصل خطا نمیدهد و نگاشت دستنخورده میماند', ! is_wp_error( $connect_again ) && ! empty( $connect_again['already_connected'] ) && 'VERIFY-1' === TCAS_Mapping::remote_code( 600 ) );
$deleted = local_product( 601, 'SKU-601' );
TCAS_Mapping::map( 601, 'VERIFY-3', true, 'ariocase', false );
unset( $GLOBALS['products'][601] );
pair_test( 'محصول حدفشده با وجود نگاشت، متصل زنده حساب نمیشود', ! TCAS_Pairing::connected_state( array( 'local_code' => 'ID:601', 'remote_code' => 'VERIFY-3' ) ) );


// نگاشت قدیمی که بهجای ID، SKU ذخیره کرده: هویت متا باید والد را هم چک کند.
local_product( 602, 'SKU-602' );
TCAS_Mapping::map( 602, 'AR-LEGACY', true, 'ariocase', false );
update_post_meta( 602, TCAS_Mapping::META_REMOTE_ID, 42925 );
update_post_meta( 602, TCAS_Mapping::META_PARENT_ID, 42678 );
pair_test( 'نگاشت قدیمی SKU با هویت ذخیرهشدهٔ همان Variation همارز است', TCAS_Pairing::connected_state( array( 'local_code' => 'ID:602', 'remote_code' => 'ID:42678/42925' ) ) );
update_post_meta( 602, TCAS_Mapping::META_PARENT_ID, 99999 );
pair_test( 'والد متفاوت در نگاشت قدیمی SKU، همارز حساب نمیشود', ! TCAS_Pairing::connected_state( array( 'local_code' => 'ID:602', 'remote_code' => 'ID:42678/42925' ) ) );

echo "\n{$pass} passed, {$fail} failed\n";
if ( ! defined( 'TCAS_TEST_NO_EXIT' ) ) exit( $fail ? 1 : 0 );
